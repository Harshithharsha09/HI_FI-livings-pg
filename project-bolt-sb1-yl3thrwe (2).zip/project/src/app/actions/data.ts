'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

type ActionResult<T = void> = { success: boolean; data?: T; error?: string }

// ============ ROOMS ============
export async function getRooms(): Promise<ActionResult<{ rooms: any[] }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const { data, error } = await supabase.from('rooms').select('*').eq('user_id', user.id).order('floor').order('number')
  if (error) return { success: false, error: error.message }
  return { success: true, data: { rooms: data || [] } }
}

export async function addRoom(formData: FormData): Promise<ActionResult<{ id: string }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const number = formData.get('number') as string
  const floor = parseInt(formData.get('floor') as string)
  const type = formData.get('type') as string
  const bedsStr = formData.get('beds') as string
  const monthlyRent = parseInt(formData.get('monthly_rent') as string)

  if (!number || isNaN(floor) || !type || isNaN(monthlyRent)) {
    return { success: false, error: 'All fields required' }
  }

  const beds = bedsStr ? bedsStr.split(',').map(b => b.trim()).filter(Boolean) : []

  const { data, error } = await supabase.from('rooms')
    .insert({ user_id: user.id, number, floor, type, beds, monthly_rent: monthlyRent })
    .select('id').single()

  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true, data: { id: data.id } }
}

export async function deleteRoom(formData: FormData): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const id = formData.get('id') as string
  const { error } = await supabase.from('rooms').delete().eq('id', id).eq('user_id', user.id)
  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true }
}

// ============ TENANTS ============
export async function getTenants(): Promise<ActionResult<{ tenants: any[] }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const { data, error } = await supabase.from('tenants')
    .select('*, rooms(id, number, floor, type, beds, monthly_rent)')
    .eq('user_id', user.id).eq('is_active', true).order('created_at', { ascending: false })

  if (error) return { success: false, error: error.message }
  return { success: true, data: { tenants: data || [] } }
}

export async function addTenant(formData: FormData): Promise<ActionResult<{ id: string }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const name = formData.get('name') as string
  const phone = formData.get('phone') as string
  const roomId = formData.get('room_id') as string | null
  const cot = formData.get('cot') as string | null
  const rent = parseInt(formData.get('rent') as string)
  const deposit = parseInt(formData.get('deposit') as string) || 0
  const joinDate = formData.get('join_date') as string | null

  if (!name || !phone || isNaN(rent)) return { success: false, error: 'Name, phone, rent required' }

  const { data, error } = await supabase.from('tenants')
    .insert({ user_id: user.id, name, phone, room_id: roomId || null, cot, rent, deposit, join_date: joinDate || null, is_approved: true })
    .select('id').single()

  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true, data: { id: data.id } }
}

export async function deleteTenant(formData: FormData): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const id = formData.get('id') as string
  const { error } = await supabase.from('tenants').update({ is_active: false }).eq('id', id).eq('user_id', user.id)
  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true }
}

// ============ PAYMENTS ============
export async function getPayments(month: number, year: number): Promise<ActionResult<{ payments: any[] }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const { data, error } = await supabase.from('payments')
    .select('*, tenants(name, phone, room_id, cot, rooms(id, number))')
    .eq('user_id', user.id).eq('month', month).eq('year', year).order('payment_date', { ascending: false })

  if (error) return { success: false, error: error.message }
  return { success: true, data: { payments: data || [] } }
}

export async function addPayment(formData: FormData): Promise<ActionResult<{ id: string }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const tenantId = formData.get('tenant_id') as string
  const month = parseInt(formData.get('month') as string)
  const year = parseInt(formData.get('year') as string)
  const amount = parseInt(formData.get('amount') as string)
  const paymentDate = formData.get('payment_date') as string
  const mode = formData.get('mode') as string
  const note = formData.get('note') as string | null
  const status = formData.get('status') as string || 'confirmed'
  const recordedBy = formData.get('recorded_by') as string || 'admin'

  if (!tenantId || isNaN(month) || isNaN(year) || isNaN(amount) || !paymentDate || !mode) {
    return { success: false, error: 'Required fields missing' }
  }

  const { data, error } = await supabase.from('payments')
    .insert({ user_id: user.id, tenant_id: tenantId, month, year, amount, payment_date: paymentDate, mode, note, status, recorded_by: recordedBy })
    .select('id').single()

  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true, data: { id: data.id } }
}

export async function updatePaymentStatus(formData: FormData): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const id = formData.get('id') as string
  const status = formData.get('status') as string

  const { error } = await supabase.from('payments').update({ status }).eq('id', id).eq('user_id', user.id)
  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true }
}

export async function deletePayment(formData: FormData): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const id = formData.get('id') as string
  const { error } = await supabase.from('payments').delete().eq('id', id).eq('user_id', user.id)
  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true }
}

export async function getPaymentHistory(): Promise<ActionResult<{ payments: any[] }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const { data, error } = await supabase.from('payments')
    .select('*, tenants(name, phone, room_id, cot, rooms(id, number))')
    .eq('user_id', user.id).order('created_at', { ascending: false }).limit(200)

  if (error) return { success: false, error: error.message }
  return { success: true, data: { payments: data || [] } }
}

// ============ NOTICES ============
export async function getNotices(): Promise<ActionResult<{ notices: any[] }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const { data, error } = await supabase.from('notices').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
  if (error) return { success: false, error: error.message }
  return { success: true, data: { notices: data || [] } }
}

export async function addNotice(formData: FormData): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const title = formData.get('title') as string
  const body = formData.get('body') as string
  const priority = formData.get('priority') as string

  if (!title || !body) return { success: false, error: 'Title and body required' }

  const { error } = await supabase.from('notices').insert({ user_id: user.id, title, body, priority: priority || 'normal' })
  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true }
}

export async function deleteNotice(formData: FormData): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const id = formData.get('id') as string
  const { error } = await supabase.from('notices').delete().eq('id', id).eq('user_id', user.id)
  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true }
}

// ============ REGISTRATIONS ============
export async function getRegistrations(): Promise<ActionResult<{ registrations: any[] }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const { data, error } = await supabase.from('registrations').select('*').eq('user_id', user.id).eq('status', 'pending')
  if (error) return { success: false, error: error.message }
  return { success: true, data: { registrations: data || [] } }
}

export async function approveRegistration(formData: FormData): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const id = formData.get('id') as string
  const name = formData.get('name') as string
  const phone = formData.get('phone') as string
  const roomId = formData.get('room_id') as string | null
  const cot = formData.get('cot') as string | null
  const rent = parseInt(formData.get('rent') as string)
  const deposit = parseInt(formData.get('deposit') as string) || 0

  const { error: tenantError } = await supabase.from('tenants')
    .insert({ user_id: user.id, name, phone, room_id: roomId || null, cot, rent, deposit, is_approved: true })

  if (tenantError) return { success: false, error: tenantError.message }

  const { error: regError } = await supabase.from('registrations').update({ status: 'approved' }).eq('id', id)
  if (regError) return { success: false, error: regError.message }

  revalidatePath('/', 'layout')
  return { success: true }
}

export async function rejectRegistration(formData: FormData): Promise<ActionResult> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const id = formData.get('id') as string
  const { error } = await supabase.from('registrations').update({ status: 'rejected' }).eq('id', id)
  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true }
}

// ============ TENANT DATA ============
export async function getTenantData(tenantId: string): Promise<ActionResult<{ tenant: any; payments: any[]; notices: any[] }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const { data: tenant, error: tenantError } = await supabase.from('tenants').select('*, rooms(id, number, floor, type, beds, monthly_rent)').eq('id', tenantId).single()
  if (tenantError) return { success: false, error: tenantError.message }

  const { data: payments } = await supabase.from('payments').select('*').eq('tenant_id', tenantId).order('created_at', { ascending: false })
  const { data: notices } = await supabase.from('notices').select('*').eq('user_id', tenant.user_id).order('created_at', { ascending: false })

  return { success: true, data: { tenant, payments: payments || [], notices: notices || [] } }
}

export async function tenantSubmitPayment(formData: FormData): Promise<ActionResult<{ id: string }>> {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'Not authenticated' }

  const tenantId = formData.get('tenant_id') as string
  const month = parseInt(formData.get('month') as string)
  const year = parseInt(formData.get('year') as string)
  const amount = parseInt(formData.get('amount') as string)
  const paymentDate = formData.get('payment_date') as string
  const mode = formData.get('mode') as string
  const note = formData.get('note') as string | null

  if (!tenantId || isNaN(month) || isNaN(year) || isNaN(amount) || !paymentDate || !mode) {
    return { success: false, error: 'Required fields missing' }
  }

  const { data: tenant } = await supabase.from('tenants').select('user_id').eq('id', tenantId).single()
  if (!tenant) return { success: false, error: 'Tenant not found' }

  const { data, error } = await supabase.from('payments')
    .insert({ user_id: tenant.user_id, tenant_id: tenantId, month, year, amount, payment_date: paymentDate, mode, note, status: 'pending', recorded_by: 'tenant' })
    .select('id').single()

  if (error) return { success: false, error: error.message }
  revalidatePath('/', 'layout')
  return { success: true, data: { id: data.id } }
}
