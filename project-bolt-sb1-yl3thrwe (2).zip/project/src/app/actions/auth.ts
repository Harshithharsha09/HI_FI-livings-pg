'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

export type ActionResult<T = void> = { success: boolean; data?: T; error?: string }

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const EF_URL = `${SUPABASE_URL}/functions/v1/admin-login`

async function callEdgeFunction(payload: Record<string, string | number | boolean | null | undefined>) {
  const res = await fetch(EF_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${ANON_KEY}` },
    body: JSON.stringify(payload),
  })
  return res.json()
}

// Admin signup
export async function adminSignup(formData: FormData): Promise<ActionResult<{ name: string }>> {
  const supabase = await createClient()
  const username = formData.get('username') as string
  const password = formData.get('password') as string
  const name = formData.get('name') as string

  if (!username || !password || !name) return { success: false, error: 'All fields required' }
  if (password.length < 6) return { success: false, error: 'Password must be 6+ characters' }

  const email = `${username}@hifi.internal`

  const { data, error } = await supabase.auth.signUp({ email, password })
  if (error) {
    if (error.message.includes('already registered')) {
      const { error: signInError } = await supabase.auth.signInWithPassword({ email, password })
      if (signInError) return { success: false, error: 'Invalid credentials' }
      const { data: { user } } = await supabase.auth.getUser()
      if (user) await callEdgeFunction({ action: 'link_admin_user', username, user_id: user.id })
      revalidatePath('/', 'layout')
      return { success: true, data: { name } }
    }
    return { success: false, error: error.message }
  }

  const userId = data.user?.id
  if (userId) await callEdgeFunction({ action: 'add_admin', username, password, name, user_id: userId })

  revalidatePath('/', 'layout')
  return { success: true, data: { name } }
}

// Admin login
export async function adminLogin(formData: FormData): Promise<ActionResult<{ name: string }>> {
  const supabase = await createClient()
  const username = formData.get('username') as string
  const password = formData.get('password') as string

  if (!username || !password) return { success: false, error: 'Username and password required' }

  const result = await callEdgeFunction({ action: 'admin_login', username, password })
  if (result.error || !result.success || !result.admin) return { success: false, error: 'Invalid credentials' }

  const admin = result.admin
  const email = `${admin.username}@hifi.internal`

  const { error: signInError } = await supabase.auth.signInWithPassword({ email, password })
  if (!signInError) {
    const { data: { user } } = await supabase.auth.getUser()
    if (user && !admin.user_id) await callEdgeFunction({ action: 'link_admin_user', username, user_id: user.id })
    revalidatePath('/', 'layout')
    return { success: true, data: { name: admin.name } }
  }

  const { data: signUpData, error: signUpError } = await supabase.auth.signUp({ email, password })
  if (signUpError) return { success: false, error: 'Failed to create session' }

  if (signUpData.user?.id) await callEdgeFunction({ action: 'link_admin_user', username, user_id: signUpData.user.id })

  revalidatePath('/', 'layout')
  return { success: true, data: { name: admin.name } }
}

// Tenant login
export async function tenantLogin(formData: FormData): Promise<ActionResult<{ name: string; tenantId: string }>> {
  const supabase = await createClient()
  const phone = formData.get('phone') as string

  if (!phone) return { success: false, error: 'Phone number required' }

  const result = await callEdgeFunction({ action: 'tenant_lookup', phone })
  if (result.error) return { success: false, error: result.error === 'Not found' ? 'Phone not registered. Please register first.' : result.error }
  if (!result.success || !result.tenant) return { success: false, error: 'Phone not registered' }

  const tenant = result.tenant
  const admin = result.admin

  if (!admin) return { success: false, error: 'No admin account found. Contact support.' }

  const adminEmail = `${admin.username}@hifi.internal`

  const { error: signInError } = await supabase.auth.signInWithPassword({ email: adminEmail, password: admin.password })
  if (signInError) {
    const { error: signUpErr } = await supabase.auth.signUp({ email: adminEmail, password: admin.password })
    if (signUpErr) return { success: false, error: 'Session error' }
  }

  // Set app_metadata with tenant info (server-only, used for UI routing only)
  const { data: { user } } = await supabase.auth.getUser()
  if (user) {
    await callEdgeFunction({ action: 'set_app_metadata', user_id: user.id, tenant_id: tenant.id, tenant_name: tenant.name, phone: tenant.phone })
  }

  revalidatePath('/', 'layout')
  return { success: true, data: { name: tenant.name, tenantId: tenant.id } }
}

// Submit registration
export async function submitRegistration(formData: FormData): Promise<ActionResult> {
  const name = formData.get('name') as string
  const phone = formData.get('phone') as string
  const preferredRoom = formData.get('preferred_room') as string | null
  const cot = formData.get('cot') as string | null
  const note = formData.get('note') as string | null

  if (!name || !phone) return { success: false, error: 'Name and phone required' }

  const result = await callEdgeFunction({ action: 'tenant_register', name, phone, preferred_room: preferredRoom, cot, note })
  if (result.error) return { success: false, error: result.error }

  return { success: true }
}

// Admin CRUD via edge function
export async function getAdminsSecure(): Promise<ActionResult<{ admins: any[] }>> {
  const result = await callEdgeFunction({ action: 'get_admins' })
  if (result.error) return { success: false, error: result.error }
  return { success: true, data: { admins: result.admins || [] } }
}

export async function addAdminSecure(formData: FormData): Promise<ActionResult> {
  const username = formData.get('username') as string
  const password = formData.get('password') as string
  const name = formData.get('name') as string
  if (!username || !password || !name) return { success: false, error: 'All fields required' }

  const result = await callEdgeFunction({ action: 'add_admin', username, password, name })
  if (result.error) return { success: false, error: result.error }
  return { success: true }
}

export async function deleteAdminSecure(id: string): Promise<ActionResult> {
  const result = await callEdgeFunction({ action: 'delete_admin', id })
  if (result.error) return { success: false, error: result.error }
  return { success: true }
}

// Sign out
export async function signOut(): Promise<ActionResult> {
  const supabase = await createClient()
  await supabase.auth.signOut()
  revalidatePath('/', 'layout')
  return { success: true }
}
