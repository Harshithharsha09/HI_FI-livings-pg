'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/lib/auth-context'
import { signOut as authSignOut, getAdminsSecure, addAdminSecure, deleteAdminSecure } from '@/app/actions/auth'
import {
  addRoom, deleteRoom, addTenant, deleteTenant, addPayment, deletePayment,
  updatePaymentStatus, addNotice, deleteNotice, approveRegistration, rejectRegistration
} from '@/app/actions/data'
import {
  LayoutDashboard, DoorOpen, Users, CreditCard, Receipt, History, Bell,
  UserCog, Settings, LogOut, Plus, Trash2, Check, X, AlertCircle, CheckCircle, Clock, Home, Loader2
} from 'lucide-react'

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const CURRENT_DATE = new Date()
const CURRENT_MONTH = CURRENT_DATE.getMonth()
const CURRENT_YEAR = CURRENT_DATE.getFullYear()

type TabType = 'dashboard' | 'rooms' | 'tenants' | 'payments' | 'receipts' | 'history' | 'notices' | 'admins' | 'approvals' | 'settings'

export function AdminDashboard({ userName }: { userName: string }) {
  const { user, signOut: authContextSignOut } = useAuth()
  const [tab, setTab] = useState<TabType>('dashboard')
  const [selectedMonth, setSelectedMonth] = useState(CURRENT_MONTH)
  const [selectedYear, setSelectedYear] = useState(CURRENT_YEAR)
  const [rooms, setRooms] = useState<any[]>([])
  const [tenants, setTenants] = useState<any[]>([])
  const [payments, setPayments] = useState<any[]>([])
  const [historyPayments, setHistoryPayments] = useState<any[]>([])
  const [notices, setNotices] = useState<any[]>([])
  const [registrations, setRegistrations] = useState<any[]>([])
  const [admins, setAdmins] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)
  const [receiptPayment, setReceiptPayment] = useState<any | null>(null)

  const supabase = useMemo(() => createClient(), [])

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 3000)
  }

  const fetchData = useCallback(async () => {
    if (!user) return
    setLoading(true)
    setError(null)
    try {
      const [roomsRes, tenantsRes, paymentsRes, historyRes, noticesRes, regsRes, adminsResult] = await Promise.all([
        supabase.from('rooms').select('*').eq('user_id', user.id).order('floor').order('number'),
        supabase.from('tenants').select('*, rooms(id, number, floor, type, beds)').eq('user_id', user.id).eq('is_active', true),
        supabase.from('payments').select('*, tenants(name, phone, room_id, cot, rooms(number))').eq('user_id', user.id).eq('month', selectedMonth).eq('year', selectedYear),
        supabase.from('payments').select('*, tenants(name, phone, room_id, cot, rooms(number))').eq('user_id', user.id).order('created_at', { ascending: false }).limit(200),
        supabase.from('notices').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('registrations').select('*').eq('user_id', user.id).eq('status', 'pending'),
        getAdminsSecure()
      ])

      if (roomsRes.data) setRooms(roomsRes.data)
      if (tenantsRes.data) setTenants(tenantsRes.data)
      if (paymentsRes.data) setPayments(paymentsRes.data)
      if (historyRes.data) setHistoryPayments(historyRes.data)
      if (noticesRes.data) setNotices(noticesRes.data)
      if (regsRes.data) setRegistrations(regsRes.data)
      if (adminsResult.success && adminsResult.data) setAdmins(adminsResult.data.admins)
    } catch (err) {
      console.error('Dashboard load error:', err)
      setError('Failed to load dashboard data.')
    } finally {
      setLoading(false)
    }
  }, [user, selectedMonth, selectedYear, supabase])

  useEffect(() => { fetchData() }, [fetchData])

  const handleSignOut = async () => { await authSignOut(); await authContextSignOut(); window.location.href = '/' }

  const pendingRegs = registrations.filter(r => r.status === 'pending').length
  const pendingPayments = payments.filter(p => p.status === 'pending').length
  const paidTenantIds = new Set(payments.filter(p => p.status === 'confirmed').map(p => p.tenant_id))
  const unpaidTenants = tenants.filter(t => !paidTenantIds.has(t.id))
  const paidTenants = tenants.filter(t => paidTenantIds.has(t.id))
  const totalCollected = payments.filter(p => p.status === 'confirmed').reduce((s, p) => s + p.amount, 0)
  const totalExpected = tenants.reduce((s, t) => s + t.rent, 0)
  const totalBeds = rooms.reduce((s, r) => s + (r.beds?.length || 0), 0)
  const collectionPercent = totalExpected > 0 ? Math.round((totalCollected / totalExpected) * 100) : 0
  const occupancyPercent = totalBeds > 0 ? Math.round((tenants.length / totalBeds) * 100) : 0

  const navItems = [
    { id: 'dashboard' as TabType, icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'rooms' as TabType, icon: DoorOpen, label: 'Rooms' },
    { id: 'tenants' as TabType, icon: Users, label: 'Tenants' },
    { id: 'payments' as TabType, icon: CreditCard, label: 'Payments', badge: pendingPayments },
    { id: 'receipts' as TabType, icon: Receipt, label: 'Receipts', badge: pendingPayments },
    { id: 'history' as TabType, icon: History, label: 'History' },
    { id: 'notices' as TabType, icon: Bell, label: 'Notices' },
    { id: 'approvals' as TabType, icon: Check, label: 'Approvals', badge: pendingRegs },
    { id: 'admins' as TabType, icon: UserCog, label: 'Admins' },
    { id: 'settings' as TabType, icon: Settings, label: 'Settings' },
  ]

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-[var(--primary)]" /></div>
  if (error) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="card text-center p-8"><p className="text-[var(--error)] mb-4">{error}</p><button onClick={() => window.location.reload()} className="btn btn-primary">Retry</button></div>
    </div>
  )

  return (
    <div className="flex min-h-screen">
      <aside className="w-64 bg-[var(--card)] border-r border-[var(--border)] flex flex-col sticky top-0 h-screen">
        <div className="p-5 border-b border-[var(--border)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#4f46e5] to-[#0284c7] flex items-center justify-center">
              <Home className="w-5 h-5 text-white" />
            </div>
            <div><div className="font-bold">HI-FI Livings</div><div className="text-xs text-[var(--muted)]">Admin Panel</div></div>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map(({ id, icon: Icon, label, badge }) => (
            <button key={id} onClick={() => setTab(id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${tab === id ? 'bg-gradient-to-r from-[#4f46e5]/20 to-[#0284c7]/20 text-white border-l-2 border-[#4f46e5]' : 'text-[var(--muted)] hover:bg-[var(--card-hover)] hover:text-white'}`}>
              <Icon className="w-5 h-5" />
              <span className="flex-1 text-left">{label}</span>
              {badge && badge > 0 && <span className="bg-[var(--error)] text-white text-xs px-2 py-0.5 rounded-full">{badge}</span>}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-[var(--border)]">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#4f46e5] to-[#0284c7] flex items-center justify-center">{userName.charAt(0).toUpperCase()}</div>
            <div className="flex-1 min-w-0"><div className="font-medium truncate">{userName}</div><div className="text-xs text-[var(--muted)]">Administrator</div></div>
          </div>
          <button onClick={handleSignOut} className="btn btn-secondary w-full text-[var(--error)]"><LogOut className="w-4 h-4" /> Sign Out</button>
        </div>
      </aside>

      <main className="flex-1 p-6 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <select value={selectedMonth} onChange={(e) => setSelectedMonth(parseInt(e.target.value))} className="w-auto">
                {MONTHS.map((m, i) => <option key={i} value={i}>{m}</option>)}
              </select>
              <select value={selectedYear} onChange={(e) => setSelectedYear(parseInt(e.target.value))} className="w-auto">
                {[CURRENT_YEAR - 1, CURRENT_YEAR, CURRENT_YEAR + 1].map(y => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>
          </div>

          {tab === 'dashboard' && (
            <div className="fade-up space-y-6">
              {(pendingPayments > 0 || pendingRegs > 0) && (
                <div className="card border-l-4 border-l-[var(--warning)] bg-[var(--warning)]/10">
                  <AlertCircle className="w-5 h-5 text-[var(--warning)] inline mr-2" />
                  {pendingPayments > 0 && <span className="font-semibold">{pendingPayments} pending payment(s). </span>}
                  {pendingRegs > 0 && <span className="font-semibold">{pendingRegs} registration(s) pending approval.</span>}
                </div>
              )}
              <div className="grid grid-cols-4 gap-4">
                <div className="card border-l-4 border-l-[#4f46e5]"><div className="text-sm text-[var(--muted)] mb-1">Occupancy</div><div className="text-2xl font-bold">{tenants.length}/{totalBeds}</div><div className="text-sm text-[var(--muted)]">{occupancyPercent}%</div></div>
                <div className="card border-l-4 border-l-[var(--success)]"><div className="text-sm text-[var(--muted)] mb-1">Paid</div><div className="text-2xl font-bold">{paidTenants.length}</div><div className="text-sm text-[var(--success)]">This month</div></div>
                <div className="card border-l-4 border-l-[var(--warning)]"><div className="text-sm text-[var(--muted)] mb-1">Pending</div><div className="text-2xl font-bold">{unpaidTenants.length}</div><div className="text-sm text-[var(--warning)]">Rent due</div></div>
                <div className="card border-l-4 border-l-[#0284c7]"><div className="text-sm text-[var(--muted)] mb-1">Collected</div><div className="text-2xl font-bold">₹{totalCollected.toLocaleString()}</div><div className="text-sm text-[var(--muted)]">of ₹{totalExpected.toLocaleString()}</div></div>
              </div>
              <div className="card">
                <div className="flex justify-between mb-3"><span className="font-semibold">Collection Progress — {MONTHS[selectedMonth]} {selectedYear}</span><span className="font-bold text-[#4f46e5]">{collectionPercent}%</span></div>
                <div className="h-4 bg-[var(--background)] rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-[#4f46e5] to-[var(--success)]" style={{ width: `${Math.min(collectionPercent, 100)}%` }} /></div>
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div className="card">
                  <h3 className="font-bold text-[var(--success)] mb-4 flex items-center gap-2"><CheckCircle className="w-5 h-5" /> Paid ({paidTenants.length})</h3>
                  {paidTenants.length === 0 ? <p className="text-[var(--muted)] text-sm">No payments yet</p> : (
                    <div className="space-y-3 max-h-80 overflow-y-auto">
                      {paidTenants.map((t: any) => {
                        const p = payments.find(p => p.tenant_id === t.id && p.status === 'confirmed')
                        return (
                          <div key={t.id} className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                            <div><div className="font-semibold">{t.name}</div><div className="text-xs text-[var(--muted)]">Room {t.rooms?.number || '-'} • {t.cot || '-'}</div></div>
                            <div className="font-bold text-[var(--success)]">₹{p?.amount?.toLocaleString() || '-'}</div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
                <div className="card">
                  <h3 className="font-bold text-[var(--warning)] mb-4 flex items-center gap-2"><Clock className="w-5 h-5" /> Pending ({unpaidTenants.length})</h3>
                  {unpaidTenants.length === 0 ? <p className="text-[var(--muted)] text-sm">All tenants paid!</p> : (
                    <div className="space-y-3 max-h-80 overflow-y-auto">
                      {unpaidTenants.map((t: any) => (
                        <div key={t.id} className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                          <div><div className="font-semibold">{t.name}</div><div className="text-xs text-[var(--muted)]">Room {t.rooms?.number || '-'} • {t.cot || '-'}</div></div>
                          <div className="font-bold text-[var(--warning)]">₹{t.rent.toLocaleString()}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {tab === 'rooms' && <RoomsTab rooms={rooms} showToast={showToast} />}
          {tab === 'tenants' && <TenantsTab tenants={tenants} rooms={rooms} paidTenantIds={paidTenantIds} showToast={showToast} />}
          {tab === 'payments' && <PaymentsTab tenants={tenants} payments={payments} unpaidTenants={unpaidTenants} selectedMonth={selectedMonth} selectedYear={selectedYear} showToast={showToast} onViewReceipt={setReceiptPayment} />}
          {tab === 'receipts' && <ReceiptsTab payments={payments.filter(p => p.status === 'pending')} showToast={showToast} onAction={fetchData} />}
          {tab === 'history' && <HistoryTab payments={historyPayments} onViewReceipt={setReceiptPayment} />}
          {tab === 'notices' && <NoticesTab notices={notices} showToast={showToast} />}
          {tab === 'approvals' && <ApprovalsTab registrations={registrations} rooms={rooms} showToast={showToast} onAction={fetchData} />}
          {tab === 'admins' && <AdminsTab admins={admins} showToast={showToast} />}
          {tab === 'settings' && <SettingsTab rooms={rooms} tenants={tenants} payments={historyPayments} showToast={showToast} />}
        </div>
      </main>
      {toast && <div className={`toast toast-${toast.type}`}>{toast.message}</div>}

      {receiptPayment && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setReceiptPayment(null)}>
          <div className="modal" style={{ maxWidth: '400px' }}>
            <div className="bg-gradient-to-br from-[#4f46e5] to-[#0284c7] rounded-xl p-6 mb-6 -mt-2 -mx-2 text-white text-center">
              <Home className="w-8 h-8 mx-auto mb-2" />
              <div className="font-bold text-xl">HI-FI Livings</div>
              <div className="text-sm opacity-80">Digital Receipt</div>
            </div>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-[var(--muted)]">Receipt No</span><span className="font-mono font-bold">{(receiptPayment.id as string).substring(0, 8).toUpperCase()}</span></div>
              <div className="flex justify-between"><span className="text-[var(--muted)]">Tenant</span><span className="font-semibold">{receiptPayment.tenants?.name || '-'}</span></div>
              <div className="flex justify-between"><span className="text-[var(--muted)]">Room / Cot</span><span>{receiptPayment.tenants?.rooms?.number || '-'} / {receiptPayment.tenants?.cot || '-'}</span></div>
              <div className="flex justify-between"><span className="text-[var(--muted)]">Date</span><span>{receiptPayment.payment_date}</span></div>
              <div className="flex justify-between"><span className="text-[var(--muted)]">Mode</span><span className={`mode-${receiptPayment.mode?.toLowerCase().replace('/', '-')}`}>{receiptPayment.mode}</span></div>
              <div className="flex justify-between border-t border-[var(--border)] pt-3 mt-3">
                <span className="font-bold">Amount</span>
                <span className="font-bold text-[var(--success)] text-lg font-mono">₹{receiptPayment.amount?.toLocaleString()}</span>
              </div>
              <div className="flex justify-between"><span className="text-[var(--muted)]">Period</span><span>{MONTHS[receiptPayment.month]} {receiptPayment.year}</span></div>
              <div className="flex justify-between"><span className="text-[var(--muted)]">Status</span><span className="text-[var(--success)] font-bold">Confirmed</span></div>
            </div>
            <div className="mt-6 pt-4 border-t border-[var(--border)] text-center text-xs text-[var(--muted)]">
              Computer-generated receipt — HI-FI Livings
            </div>
            <button onClick={() => setReceiptPayment(null)} className="btn btn-secondary w-full mt-4">Close</button>
          </div>
        </div>
      )}
    </div>
  )
}

function RoomsTab({ rooms, showToast }: any) {
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ number: '', floor: '1', type: 'Double', beds: 'A,B', monthly_rent: '' })

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => fd.append(k, v as string))
    const result = await addRoom(fd)
    if (result.success) { showToast('Room added!'); setShowModal(false); window.location.reload() }
    else showToast(result.error || 'Failed', 'error')
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this room?')) return
    const fd = new FormData(); fd.append('id', id)
    const result = await deleteRoom(fd)
    if (result.success) showToast('Room deleted')
    else showToast(result.error || 'Failed', 'error')
  }

  const grouped = rooms.reduce((acc: any, r: any) => { acc[r.floor] = acc[r.floor] || []; acc[r.floor].push(r); return acc }, {})

  return (
    <div className="fade-up">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Rooms ({rooms.length})</h2>
        <button onClick={() => setShowModal(true)} className="btn btn-primary"><Plus className="w-4 h-4" /> Add Room</button>
      </div>
      {rooms.length === 0 ? <div className="card text-center py-12 text-[var(--muted)]">No rooms yet. Add your first room to get started.</div> : (
        Object.entries(grouped).map(([floor, floorRooms]: [string, any]) => (
          <div key={floor} className="mb-6">
            <h3 className="text-sm font-bold text-[var(--muted)] uppercase mb-3">Floor {floor}</h3>
            <div className="grid grid-cols-3 gap-4">
              {floorRooms.map((room: any) => (
                <div key={room.id} className="card">
                  <div className="flex justify-between items-start mb-3">
                    <div><div className="font-bold text-lg">{room.number}</div><div className="text-xs text-[var(--muted)]">{room.type} • ₹{room.monthly_rent}/mo</div></div>
                    <button onClick={() => handleDelete(room.id)} className="text-[var(--error)] hover:bg-[var(--error)]/10 p-1.5 rounded"><Trash2 className="w-4 h-4" /></button>
                  </div>
                  <div className="flex flex-wrap gap-2">{(room.beds || []).map((bed: string) => <span key={bed} className="badge badge-success text-xs">{bed}</span>)}</div>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
      {showModal && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <h3 className="text-lg font-bold mb-4">Add Room</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-sm text-[var(--muted)] mb-1 block">Room Number</label><input value={form.number} onChange={(e) => setForm({...form, number: e.target.value})} required /></div>
                <div><label className="text-sm text-[var(--muted)] mb-1 block">Floor</label><input type="number" value={form.floor} onChange={(e) => setForm({...form, floor: e.target.value})} required /></div>
              </div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Type</label><select value={form.type} onChange={(e) => setForm({...form, type: e.target.value})}><option>Single</option><option>Double</option><option>Triple</option><option>Quad</option></select></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Beds (comma separated)</label><input value={form.beds} onChange={(e) => setForm({...form, beds: e.target.value})} /></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Monthly Rent</label><input type="number" value={form.monthly_rent} onChange={(e) => setForm({...form, monthly_rent: e.target.value})} required /></div>
              <div className="flex gap-3 pt-4"><button type="submit" className="btn btn-primary flex-1">Add Room</button><button type="button" onClick={() => setShowModal(false)} className="btn btn-secondary">Cancel</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

function TenantsTab({ tenants, rooms, paidTenantIds, showToast }: any) {
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name: '', phone: '', room_id: '', cot: '', rent: '', deposit: '0', join_date: '' })

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => fd.append(k, v))
    const result = await addTenant(fd)
    if (result.success) { showToast('Tenant added!'); setShowModal(false); window.location.reload() }
    else showToast(result.error || 'Failed', 'error')
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Remove tenant?')) return
    const fd = new FormData(); fd.append('id', id)
    const result = await deleteTenant(fd)
    if (result.success) showToast('Tenant removed')
    else showToast(result.error || 'Failed', 'error')
  }

  const selectedRoom = rooms.find((r: any) => r.id === form.room_id)

  return (
    <div className="fade-up">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Tenants ({tenants.length})</h2>
        <button onClick={() => setShowModal(true)} className="btn btn-primary"><Plus className="w-4 h-4" /> Add Tenant</button>
      </div>
      {tenants.length === 0 ? <div className="card text-center py-12 text-[var(--muted)]">No tenants yet</div> : (
        <div className="card p-0 overflow-hidden">
          <table>
            <thead><tr><th>Name</th><th>Room/Cot</th><th>Phone</th><th>Rent</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {tenants.map((t: any) => (
                <tr key={t.id}>
                  <td className="font-semibold">{t.name}</td>
                  <td>Rm {t.rooms?.number || '-'} / {t.cot || '-'}</td>
                  <td className="text-[var(--muted)]">{t.phone}</td>
                  <td className="font-bold">₹{t.rent.toLocaleString()}</td>
                  <td>{paidTenantIds.has(t.id) ? <span className="badge badge-success">Paid</span> : <span className="badge badge-warning">Pending</span>}</td>
                  <td><button onClick={() => handleDelete(t.id)} className="btn btn-danger text-xs"><Trash2 className="w-3 h-3" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {showModal && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <h3 className="text-lg font-bold mb-4">Add Tenant</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Name</label><input value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} required /></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Phone (login)</label><input value={form.phone} onChange={(e) => setForm({...form, phone: e.target.value})} required /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-sm text-[var(--muted)] mb-1 block">Room</label><select value={form.room_id} onChange={(e) => setForm({...form, room_id: e.target.value, cot: ''})}><option value="">Select...</option>{rooms.map((r: any) => <option key={r.id} value={r.id}>{r.number}</option>)}</select></div>
                <div><label className="text-sm text-[var(--muted)] mb-1 block">Cot</label><select value={form.cot} onChange={(e) => setForm({...form, cot: e.target.value})}><option value="">Select...</option>{(selectedRoom?.beds || []).map((b: string) => <option key={b} value={b}>{b}</option>)}</select></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-sm text-[var(--muted)] mb-1 block">Rent (₹)</label><input type="number" value={form.rent} onChange={(e) => setForm({...form, rent: e.target.value})} required /></div>
                <div><label className="text-sm text-[var(--muted)] mb-1 block">Deposit (₹)</label><input type="number" value={form.deposit} onChange={(e) => setForm({...form, deposit: e.target.value})} /></div>
              </div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Join Date</label><input type="date" value={form.join_date} onChange={(e) => setForm({...form, join_date: e.target.value})} /></div>
              <div className="flex gap-3 pt-4"><button type="submit" className="btn btn-primary flex-1">Add Tenant</button><button type="button" onClick={() => setShowModal(false)} className="btn btn-secondary">Cancel</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

function PaymentsTab({ tenants, payments, unpaidTenants, selectedMonth, selectedYear, showToast, onViewReceipt }: any) {
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ tenant_id: '', amount: '', payment_date: new Date().toISOString().split('T')[0], mode: 'UPI', note: '' })

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => fd.append(k, v))
    fd.append('month', String(selectedMonth)); fd.append('year', String(selectedYear)); fd.append('status', 'confirmed'); fd.append('recorded_by', 'admin')
    const result = await addPayment(fd)
    if (result.success) { showToast('Payment recorded!'); setShowModal(false); window.location.reload() }
    else showToast(result.error || 'Failed', 'error')
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete payment?')) return
    const fd = new FormData(); fd.append('id', id)
    const result = await deletePayment(fd)
    if (result.success) showToast('Payment deleted')
  }

  const confirmedPayments = payments.filter((p: any) => p.status === 'confirmed')

  return (
    <div className="fade-up">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Rent Collection — {MONTHS[selectedMonth]} {selectedYear}</h2>
        <button onClick={() => setShowModal(true)} className="btn btn-primary"><Plus className="w-4 h-4" /> Record Payment</button>
      </div>
      {unpaidTenants.length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-bold text-[var(--warning)] mb-3 flex items-center gap-2"><AlertCircle className="w-4 h-4" /> Pending ({unpaidTenants.length})</h3>
          <div className="grid grid-cols-3 gap-4">
            {unpaidTenants.map((t: any) => (
              <div key={t.id} className="card border-l-4 border-l-[var(--warning)]">
                <div className="font-bold">{t.name}</div>
                <div className="text-xs text-[var(--muted)]">Room {t.rooms?.number || '-'}</div>
                <div className="font-bold text-[var(--warning)] my-2">₹{t.rent.toLocaleString()}</div>
                <button onClick={() => { setForm({...form, tenant_id: t.id, amount: String(t.rent)}); setShowModal(true) }} className="btn btn-primary w-full text-sm">Mark Paid</button>
              </div>
            ))}
          </div>
        </div>
      )}
      {confirmedPayments.length > 0 && (
        <div className="card p-0 overflow-hidden">
          <table>
            <thead><tr><th>Tenant</th><th>Mode</th><th>Amount</th><th>Date</th><th>Receipt</th><th></th></tr></thead>
            <tbody>
              {confirmedPayments.map((p: any) => (
                <tr key={p.id}>
                  <td className="font-semibold">{p.tenants?.name || '-'}</td>
                  <td><span className={`mode-${p.mode.toLowerCase().replace('/', '-')}`}>{p.mode}</span></td>
                  <td className="font-bold text-[var(--success)]">₹{p.amount.toLocaleString()}</td>
                  <td className="text-[var(--muted)]">{p.payment_date}</td>
                  <td><button onClick={() => onViewReceipt(p)} className="btn btn-ghost text-xs text-[var(--primary)]"><Receipt className="w-3 h-3" /> View</button></td>
                  <td><button onClick={() => handleDelete(p.id)} className="btn btn-danger text-xs"><Trash2 className="w-3 h-3" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {showModal && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <h3 className="text-lg font-bold mb-4">Record Payment</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Tenant</label><select value={form.tenant_id} onChange={(e) => { const t = tenants.find((t: any) => t.id === e.target.value); setForm({...form, tenant_id: e.target.value, amount: t?.rent || form.amount}) }} required><option value="">Select...</option>{unpaidTenants.map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Amount (₹)</label><input type="number" value={form.amount} onChange={(e) => setForm({...form, amount: e.target.value})} required /></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Date</label><input type="date" value={form.payment_date} onChange={(e) => setForm({...form, payment_date: e.target.value})} required /></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Mode</label><select value={form.mode} onChange={(e) => setForm({...form, mode: e.target.value})}><option>UPI</option><option>Cash</option><option>NEFT/IMPS</option><option>Cheque</option><option>Bank Transfer</option><option>Other</option></select></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Note</label><input value={form.note} onChange={(e) => setForm({...form, note: e.target.value})} /></div>
              <div className="flex gap-3 pt-4"><button type="submit" className="btn btn-primary flex-1">Save</button><button type="button" onClick={() => setShowModal(false)} className="btn btn-secondary">Cancel</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

function ReceiptsTab({ payments, showToast, onAction }: any) {
  if (payments.length === 0) return <div className="fade-up"><h2 className="text-xl font-bold mb-6">Pending Receipts</h2><div className="card text-center py-12 text-[var(--muted)]">No pending receipts</div></div>
  return (
    <div className="fade-up">
      <h2 className="text-xl font-bold mb-6">Pending Receipts ({payments.length})</h2>
      <div className="space-y-4">
        {payments.map((p: any) => (
          <div key={p.id} className="card flex items-center justify-between">
            <div><div className="font-bold">{p.tenants?.name || 'Unknown'}</div><div className="text-sm text-[var(--muted)]">{MONTHS[p.month]} {p.year} • ₹{p.amount.toLocaleString()} • {p.mode} • {p.payment_date}</div></div>
            <div className="flex gap-2">
              <button onClick={async () => { const fd = new FormData(); fd.append('id', p.id); fd.append('status', 'confirmed'); await updatePaymentStatus(fd); showToast('Confirmed!'); onAction() }} className="btn btn-primary text-sm"><Check className="w-4 h-4" /> Confirm</button>
              <button onClick={async () => { const fd = new FormData(); fd.append('id', p.id); await deletePayment(fd); showToast('Rejected'); onAction() }} className="btn btn-danger text-sm"><X className="w-4 h-4" /> Reject</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function HistoryTab({ payments, onViewReceipt }: any) {
  if (payments.length === 0) return <div className="card text-center py-12 text-[var(--muted)]">No history</div>
  return (
    <div className="fade-up">
      <h2 className="text-xl font-bold mb-6">History ({payments.length})</h2>
      <div className="card p-0 overflow-hidden">
        <table>
          <thead><tr><th>Month</th><th>Tenant</th><th>Mode</th><th>Amount</th><th>Date</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {payments.map((p: any) => (
              <tr key={p.id}>
                <td className="font-bold text-[var(--primary)]">{MONTHS[p.month]} {p.year}</td>
                <td>{p.tenants?.name || '-'}</td>
                <td><span className={`mode-${p.mode.toLowerCase().replace('/', '-')}`}>{p.mode}</span></td>
                <td className="font-bold">₹{p.amount.toLocaleString()}</td>
                <td>{p.payment_date}</td>
                <td>{p.status === 'confirmed' ? <span className="badge badge-success">Confirmed</span> : p.status === 'pending' ? <span className="badge badge-pending">Pending</span> : <span className="badge badge-error">Rejected</span>}</td>
                <td>{p.status === 'confirmed' && <button onClick={() => onViewReceipt(p)} className="btn btn-ghost text-xs text-[var(--primary)]"><Receipt className="w-3 h-3" /></button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function NoticesTab({ notices, showToast }: any) {
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ title: '', body: '', priority: 'normal' })

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => fd.append(k, v))
    const result = await addNotice(fd)
    if (result.success) { showToast('Notice posted!'); setShowModal(false); window.location.reload() }
    else showToast(result.error || 'Failed', 'error')
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete?')) return
    const fd = new FormData(); fd.append('id', id)
    await deleteNotice(fd); showToast('Deleted'); window.location.reload()
  }

  return (
    <div className="fade-up">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Notices ({notices.length})</h2>
        <button onClick={() => setShowModal(true)} className="btn btn-primary"><Plus className="w-4 h-4" /> Post</button>
      </div>
      {notices.length === 0 ? <div className="card text-center py-12 text-[var(--muted)]">No notices</div> : (
        <div className="space-y-4">
          {notices.map((n: any) => (
            <div key={n.id} className={`card ${n.priority === 'urgent' ? 'border-l-4 border-l-[var(--error)]' : ''}`}>
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2 mb-1"><span className="font-bold">{n.title}</span>{n.priority === 'urgent' && <span className="badge badge-error">URGENT</span>}</div>
                  <p className="text-sm text-[var(--muted)]">{n.body}</p>
                </div>
                <button onClick={() => handleDelete(n.id)} className="btn btn-ghost text-[var(--error)]"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      {showModal && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <h3 className="text-lg font-bold mb-4">Post Notice</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Title</label><input value={form.title} onChange={(e) => setForm({...form, title: e.target.value})} required /></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Message</label><textarea value={form.body} onChange={(e) => setForm({...form, body: e.target.value})} rows={4} required /></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Priority</label><select value={form.priority} onChange={(e) => setForm({...form, priority: e.target.value})}><option value="normal">Normal</option><option value="urgent">Urgent</option></select></div>
              <div className="flex gap-3 pt-4"><button type="submit" className="btn btn-primary flex-1">Post</button><button type="button" onClick={() => setShowModal(false)} className="btn btn-secondary">Cancel</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

function ApprovalsTab({ registrations, rooms, showToast, onAction }: any) {
  const [forms, setForms] = useState<Record<string, any>>({})
  if (registrations.length === 0) return <div className="fade-up"><h2 className="text-xl font-bold mb-6">Approvals</h2><div className="card text-center py-12 text-[var(--muted)]">No pending registrations</div></div>
  return (
    <div className="fade-up">
      <h2 className="text-xl font-bold mb-6">Pending Registrations ({registrations.length})</h2>
      <div className="space-y-4">
        {registrations.map((r: any) => {
          const form = forms[r.id] || { room_id: '', cot: '', rent: '', deposit: '0' }
          const selectedRoom = rooms.find((room: any) => room.id === form.room_id)
          return (
            <div key={r.id} className="card">
              <div className="flex justify-between items-start mb-4">
                <div><div className="font-bold">{r.name}</div><div className="text-sm text-[var(--muted)]">{r.phone}</div>{r.note && <div className="text-xs mt-1 italic">&quot;{r.note}&quot;</div>}</div>
                <div className="text-xs text-[var(--muted)]">{new Date(r.created_at).toLocaleDateString()}</div>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <select value={form.room_id} onChange={(e) => setForms({...forms, [r.id]: {...form, room_id: e.target.value, cot: ''}})}><option value="">Assign Room...</option>{rooms.map((room: any) => <option key={room.id} value={room.id}>{room.number}</option>)}</select>
                <select value={form.cot} onChange={(e) => setForms({...forms, [r.id]: {...form, cot: e.target.value}})}><option value="">Assign Cot...</option>{(selectedRoom?.beds || []).map((b: string) => <option key={b} value={b}>{b}</option>)}</select>
                <input type="number" placeholder="Rent (₹)" value={form.rent} onChange={(e) => setForms({...forms, [r.id]: {...form, rent: e.target.value}})} />
                <input type="number" placeholder="Deposit (₹)" value={form.deposit} onChange={(e) => setForms({...forms, [r.id]: {...form, deposit: e.target.value}})} />
              </div>
              <div className="flex gap-3">
                <button onClick={async () => { const fd = new FormData(); fd.append('id', r.id); fd.append('name', r.name); fd.append('phone', r.phone); fd.append('room_id', form.room_id); fd.append('cot', form.cot); fd.append('rent', form.rent); fd.append('deposit', form.deposit); const result = await approveRegistration(fd); if (result.success) { showToast('Approved!'); onAction() } else showToast(result.error || 'Failed', 'error') }} className="btn btn-primary flex-1 text-sm"><Check className="w-4 h-4" /> Approve</button>
                <button onClick={async () => { if (!confirm('Reject?')) return; const fd = new FormData(); fd.append('id', r.id); const result = await rejectRegistration(fd); if (result.success) { showToast('Rejected'); onAction() } }} className="btn btn-danger flex-1 text-sm"><X className="w-4 h-4" /> Reject</button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function AdminsTab({ admins, showToast }: any) {
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ username: '', password: '', name: '' })

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => fd.append(k, v))
    const result = await addAdminSecure(fd)
    if (result.success) { showToast('Admin added!'); setShowModal(false); window.location.reload() }
    else showToast(result.error || 'Failed', 'error')
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete?')) return
    const result = await deleteAdminSecure(id)
    if (result.success) showToast('Deleted')
    else showToast('Cannot delete main admin', 'error')
  }

  return (
    <div className="fade-up">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Admins ({admins.length})</h2>
        <button onClick={() => setShowModal(true)} className="btn btn-primary"><Plus className="w-4 h-4" /> Add</button>
      </div>
      <div className="space-y-3">
        {admins.map((a: any) => (
          <div key={a.id} className="card flex justify-between items-center">
            <div><div className="font-bold">{a.name} {a.is_main && <span className="badge badge-success ml-2">Main</span>}</div><div className="text-sm text-[var(--muted)]">@{a.username}</div></div>
            {!a.is_main && <button onClick={() => handleDelete(a.id)} className="btn btn-danger text-xs"><Trash2 className="w-3 h-3" /></button>}
          </div>
        ))}
      </div>
      {showModal && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <h3 className="text-lg font-bold mb-4">Add Admin</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Name</label><input value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} required /></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Username</label><input value={form.username} onChange={(e) => setForm({...form, username: e.target.value})} required /></div>
              <div><label className="text-sm text-[var(--muted)] mb-1 block">Password</label><input type="password" value={form.password} onChange={(e) => setForm({...form, password: e.target.value})} required /></div>
              <div className="flex gap-3 pt-4"><button type="submit" className="btn btn-primary flex-1">Add</button><button type="button" onClick={() => setShowModal(false)} className="btn btn-secondary">Cancel</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

function SettingsTab({ rooms, tenants, payments, showToast }: any) {
  const totalBeds = rooms.reduce((s: number, r: any) => s + (r.beds?.length || 0), 0)
  const totalCollected = payments.filter((p: any) => p.status === 'confirmed').reduce((s: number, p: any) => s + p.amount, 0)
  return (
    <div className="fade-up space-y-6">
      <h2 className="text-xl font-bold">Settings</h2>
      <div className="card">
        <h3 className="font-bold mb-4">App Summary</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex justify-between"><span className="text-[var(--muted)]">Version</span><span className="font-semibold">1.0.0</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Rooms</span><span className="font-semibold">{rooms.length}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Total Beds</span><span className="font-semibold">{totalBeds}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Tenants</span><span className="font-semibold">{tenants.length}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Payments</span><span className="font-semibold">{payments.length}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">All-time Collected</span><span className="font-semibold text-[var(--success)]">₹{totalCollected.toLocaleString()}</span></div>
        </div>
      </div>
      <div className="card border border-[var(--error)]/30">
        <h3 className="font-bold text-[var(--error)] mb-4">Danger Zone</h3>
        <p className="text-sm text-[var(--muted)] mb-4">These actions cannot be undone.</p>
        <div className="space-y-3">
          <button onClick={() => { if (confirm('Delete ALL payments?')) showToast('Use Supabase dashboard to clear') }} className="btn btn-danger w-full">Clear All Payments</button>
          <button onClick={() => { if (confirm('Remove ALL tenants?')) showToast('Use Supabase dashboard to clear') }} className="btn btn-danger w-full">Clear All Tenants</button>
        </div>
      </div>
    </div>
  )
}
