'use client'

import { useState, useEffect, useMemo, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/lib/auth-context'
import { signOut as authSignOut } from '@/app/actions/auth'
import { tenantSubmitPayment } from '@/app/actions/data'
import { Home, History, CreditCard, Bell, LogOut, CheckCircle, Clock, AlertCircle, Plus, Loader2 } from 'lucide-react'

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const CURRENT_DATE = new Date()
const CURRENT_MONTH = CURRENT_DATE.getMonth()
const CURRENT_YEAR = CURRENT_DATE.getFullYear()

type TabType = 'home' | 'history' | 'pay' | 'notices'

export function TenantPortal({ tenantId, userName }: { tenantId: string; userName: string }) {
  const { signOut: authContextSignOut } = useAuth()
  const [tab, setTab] = useState<TabType>('home')
  const [tenant, setTenant] = useState<any>(null)
  const [payments, setPayments] = useState<any[]>([])
  const [notices, setNotices] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)

  const supabase = useMemo(() => createClient(), [])

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 3000)
  }

  const fetchData = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const { data: tenantData, error: tenantErr } = await supabase.from('tenants').select('*, rooms(id, number, floor, type, beds, monthly_rent)').eq('id', tenantId).single()
      if (tenantErr) {
        console.error('Tenant fetch error:', tenantErr)
        setError('Could not load tenant data.')
        return
      }
      if (tenantData) setTenant(tenantData)

      const { data: paymentsData } = await supabase.from('payments').select('*').eq('tenant_id', tenantId).order('created_at', { ascending: false })
      if (paymentsData) setPayments(paymentsData)

      if (tenantData?.user_id) {
        const { data: noticesData } = await supabase.from('notices').select('*').eq('user_id', tenantData.user_id).order('created_at', { ascending: false })
        if (noticesData) setNotices(noticesData)
      }
    } catch (err) {
      console.error('Tenant portal error:', err)
      setError('Failed to load data.')
    } finally {
      setLoading(false)
    }
  }, [tenantId, supabase])

  useEffect(() => { fetchData() }, [fetchData])

  const handleSignOut = async () => { await authSignOut(); await authContextSignOut(); window.location.href = '/' }

  const currentMonthPayment = payments.find(p => p.month === CURRENT_MONTH && p.year === CURRENT_YEAR)
  const totalPaid = payments.filter(p => p.status === 'confirmed').reduce((s, p) => s + p.amount, 0)
  const urgentCount = notices.filter(n => n.priority === 'urgent').length

  const navItems = [
    { id: 'home' as TabType, icon: Home, label: 'Home' },
    { id: 'history' as TabType, icon: History, label: 'History' },
    { id: 'pay' as TabType, icon: CreditCard, label: 'Pay' },
    { id: 'notices' as TabType, icon: Bell, label: 'Notices', badge: urgentCount > 0 ? urgentCount : null },
  ]

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-[var(--primary)]" /></div>
  if (error) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="card text-center p-8"><p className="text-[var(--error)] mb-4">{error}</p><button onClick={() => window.location.reload()} className="btn btn-primary">Retry</button></div>
    </div>
  )

  return (
    <div className="min-h-screen bg-[var(--background)] flex flex-col max-w-lg mx-auto">
      <header className="sticky top-0 bg-[var(--card)] border-b border-[var(--border)] p-4 z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#4f46e5] to-[#0284c7] flex items-center justify-center"><Home className="w-5 h-5 text-white" /></div>
            <div><div className="font-bold">HI-FI Livings</div><div className="text-xs text-[var(--muted)]">{userName}</div></div>
          </div>
          <button onClick={handleSignOut} className="btn btn-ghost text-[var(--muted)]"><LogOut className="w-5 h-5" /></button>
        </div>
      </header>

      <main className="flex-1 p-4 pb-24">
        {tab === 'home' && <HomeTab tenant={tenant} currentMonthPayment={currentMonthPayment} totalPaid={totalPaid} currentMonth={CURRENT_MONTH} currentYear={CURRENT_YEAR} />}
        {tab === 'history' && <HistoryTab payments={payments} />}
        {tab === 'pay' && <PayTab tenantId={tenantId} tenant={tenant} currentMonth={CURRENT_MONTH} currentYear={CURRENT_YEAR} currentMonthPayment={currentMonthPayment} showToast={showToast} />}
        {tab === 'notices' && <NoticesTab notices={notices} />}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto bg-[var(--card)] border-t border-[var(--border)] flex justify-around p-2 z-10">
        {navItems.map(({ id, icon: Icon, label, badge }) => (
          <button key={id} onClick={() => setTab(id)} className={`flex flex-col items-center gap-1 p-3 rounded-xl transition-all relative ${tab === id ? 'text-[var(--primary)] bg-[var(--primary)]/10' : 'text-[var(--muted)] hover:text-white'}`}>
            <Icon className="w-5 h-5" />
            <span className="text-xs font-medium">{label}</span>
            {badge && <span className="absolute -top-1 -right-1 w-5 h-5 bg-[var(--error)] text-white text-xs rounded-full flex items-center justify-center">{badge}</span>}
          </button>
        ))}
      </nav>

      {toast && <div className={`toast toast-${toast.type}`}>{toast.message}</div>}
    </div>
  )
}

function HomeTab({ tenant, currentMonthPayment, totalPaid, currentMonth, currentYear }: any) {
  const status = currentMonthPayment?.status || 'unpaid'
  const config = { confirmed: { label: 'Paid', color: 'var(--success)', icon: CheckCircle }, pending: { label: 'Under Review', color: '#fbbf24', icon: Clock }, unpaid: { label: 'Rent Due', color: 'var(--error)', icon: AlertCircle } }
  const { label, color, icon: StatusIcon } = config[status as keyof typeof config]

  return (
    <div className="fade-up space-y-4">
      <div className="card border-l-4" style={{ borderColor: color }}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: `${color}20` }}><StatusIcon className="w-7 h-7" style={{ color }} /></div>
          <div className="flex-1"><div className="font-bold text-lg">{label}</div><div className="text-sm text-[var(--muted)]">{MONTHS[currentMonth]} {currentYear}</div></div>
        </div>
        {currentMonthPayment && (
          <div className="mt-4 pt-4 border-t border-[var(--border)]">
            <div className="flex justify-between text-sm"><span className="text-[var(--muted)]">Amount</span><span className="font-bold" style={{ color }}>₹{currentMonthPayment.amount.toLocaleString()}</span></div>
            <div className="flex justify-between text-sm mt-2"><span className="text-[var(--muted)]">Date</span><span>{currentMonthPayment.payment_date}</span></div>
            <div className="flex justify-between text-sm mt-2"><span className="text-[var(--muted)]">Mode</span><span className={`mode-${currentMonthPayment.mode.toLowerCase().replace('/', '-')}`}>{currentMonthPayment.mode}</span></div>
          </div>
        )}
      </div>

      <div className="card">
        <h3 className="font-bold mb-3">Your Details</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-[var(--muted)]">Room</span><span className="font-semibold">{tenant?.rooms?.number || '-'}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Cot</span><span className="font-semibold">{tenant?.cot || '-'}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Rent</span><span className="font-semibold">₹{tenant?.rent?.toLocaleString() || '-'}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Deposit</span><span className="font-semibold">₹{tenant?.deposit?.toLocaleString() || '0'}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Member Since</span><span>{tenant?.join_date ? new Date(tenant.join_date).toLocaleDateString() : '-'}</span></div>
          <div className="flex justify-between"><span className="text-[var(--muted)]">Total Paid</span><span className="font-semibold text-[var(--success)]">₹{totalPaid.toLocaleString()}</span></div>
        </div>
      </div>
    </div>
  )
}

function HistoryTab({ payments }: any) {
  if (payments.length === 0) return <div className="card text-center py-12 text-[var(--muted)]">No history</div>
  return (
    <div className="fade-up space-y-3">
      <h2 className="font-bold text-lg mb-4">Payment History</h2>
      {payments.map((p: any) => (
        <div key={p.id} className="card">
          <div className="flex justify-between items-start mb-2">
            <div className="font-bold">{MONTHS[p.month]} {p.year}</div>
            <div>{p.status === 'confirmed' ? <span className="badge badge-success">Confirmed</span> : p.status === 'pending' ? <span className="badge badge-pending">Pending</span> : <span className="badge badge-error">Rejected</span>}</div>
          </div>
          <div className="flex justify-between text-sm"><span className="text-[var(--muted)]">Amount</span><span className="font-bold">₹{p.amount.toLocaleString()}</span></div>
          <div className="flex justify-between text-sm mt-1"><span className="text-[var(--muted)]">Date</span><span>{p.payment_date}</span></div>
          <div className="flex justify-between text-sm mt-1"><span className="text-[var(--muted)]">Mode</span><span className={`mode-${p.mode.toLowerCase().replace('/', '-')}`}>{p.mode}</span></div>
        </div>
      ))}
    </div>
  )
}

function PayTab({ tenantId, tenant, currentMonth, currentYear, currentMonthPayment, showToast }: any) {
  const [form, setForm] = useState({ month: currentMonth, year: currentYear, amount: tenant?.rent || '', payment_date: new Date().toISOString().split('T')[0], mode: 'UPI', note: '' })
  const [submitting, setSubmitting] = useState(false)

  const recentMonths = Array.from({ length: 6 }, (_, i) => { let m = currentMonth - i, y = currentYear; if (m < 0) { m += 12; y -= 1 }; return { month: m, year: y } })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setSubmitting(true)
    const fd = new FormData()
    fd.append('tenant_id', tenantId); fd.append('month', String(form.month)); fd.append('year', String(form.year))
    fd.append('amount', String(form.amount)); fd.append('payment_date', form.payment_date)
    fd.append('mode', form.mode); fd.append('note', form.note)
    const result = await tenantSubmitPayment(fd)
    setSubmitting(false)
    if (result.success) { showToast('Submitted for approval!'); window.location.reload() }
    else showToast(result.error || 'Failed', 'error')
  }

  return (
    <div className="fade-up">
      <h2 className="font-bold text-lg mb-4">Submit Payment</h2>
      {currentMonthPayment && <div className="card mb-4 border-l-4 border-l-[var(--warning)] bg-[var(--warning)]/10"><p className="text-sm">Already {currentMonthPayment.status === 'confirmed' ? 'paid' : 'submitted'} for {MONTHS[currentMonth]} {currentYear}.</p></div>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div><label className="text-sm text-[var(--muted)] mb-1 block">Month</label><select value={`${form.month}-${form.year}`} onChange={(e) => { const [m, y] = e.target.value.split('-').map(Number); setForm({ ...form, month: m, year: y }) }}>{recentMonths.map(({ month, year }) => <option key={`${month}-${year}`} value={`${month}-${year}`}>{MONTHS[month]} {year}</option>)}</select></div>
        <div><label className="text-sm text-[var(--muted)] mb-1 block">Amount (₹)</label><input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} required /></div>
        <div><label className="text-sm text-[var(--muted)] mb-1 block">Date</label><input type="date" value={form.payment_date} onChange={(e) => setForm({ ...form, payment_date: e.target.value })} required /></div>
        <div><label className="text-sm text-[var(--muted)] mb-2 block">Mode</label><div className="grid grid-cols-3 gap-2">{['UPI', 'Cash', 'NEFT/IMPS', 'Cheque', 'Bank Transfer', 'Other'].map(m => <button key={m} type="button" onClick={() => setForm({ ...form, mode: m })} className={`py-3 px-2 rounded-lg text-sm font-medium ${form.mode === m ? 'bg-[var(--primary)] text-white' : 'bg-[var(--card)] border border-[var(--border)]'}`}>{m}</button>)}</div></div>
        {form.mode === 'Cash' && <div className="card bg-[var(--warning)]/10 border-l-4 border-l-[var(--warning)] text-sm">No screenshot needed. Inform admin for confirmation.</div>}
        <div><label className="text-sm text-[var(--muted)] mb-1 block">Note</label><input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></div>
        <button type="submit" disabled={submitting} className="btn btn-primary w-full py-4">{submitting ? <><Loader2 className="w-5 h-5 animate-spin" /> Submitting...</> : <><Plus className="w-5 h-5" /> Submit Payment</>}</button>
      </form>
    </div>
  )
}

function NoticesTab({ notices }: any) {
  if (notices.length === 0) return <div className="card text-center py-12 text-[var(--muted)]">No notices</div>
  return (
    <div className="fade-up space-y-3">
      <h2 className="font-bold text-lg mb-4">Notices</h2>
      {notices.map((n: any) => (
        <div key={n.id} className={`card ${n.priority === 'urgent' ? 'border-l-4 border-l-[var(--error)]' : ''}`}>
          <div className="flex items-center gap-2 mb-1"><span className="font-bold">{n.title}</span>{n.priority === 'urgent' && <span className="badge badge-error">URGENT</span>}</div>
          <p className="text-sm text-[var(--muted)]">{n.body}</p>
          <div className="text-xs text-[var(--muted)] mt-2">{new Date(n.created_at).toLocaleDateString()}</div>
        </div>
      ))}
    </div>
  )
}
