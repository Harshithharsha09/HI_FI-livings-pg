'use client'

import { useState, useActionState, useEffect } from 'react'
import { adminLogin, adminSignup, tenantLogin, submitRegistration, ActionResult } from '@/app/actions/auth'
import { useAuth } from '@/lib/auth-context'
import { Building2, User, Users, Phone, Lock, ArrowRight, Loader2, UserPlus } from 'lucide-react'

type LoginMode = 'select' | 'admin' | 'admin-signup' | 'tenant' | 'register'

export function LoginScreen() {
  const [mode, setMode] = useState<LoginMode>('select')
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)
  const { refresh } = useAuth()

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 3000)
  }

  // After server action sets cookies, refresh auth context with retries
  // because the browser may not have the cookies immediately
  const onLoginSuccess = async () => {
    for (let i = 0; i < 5; i++) {
      await new Promise(r => setTimeout(r, 200))
      await refresh()
      // refresh() will update the auth context, and page.tsx will react to the role change
      // We rely on AuthContext detecting the session via getSession/getUser
    }
  }

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#4f46e5] to-[#0284c7] flex-col justify-center items-center p-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-2H24v2h12zM36 24v-2H24v2h12z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }}></div>
        <div className="relative z-10 text-center text-white">
          <div className="w-24 h-24 rounded-3xl bg-white/20 backdrop-blur flex items-center justify-center mx-auto mb-8">
            <Building2 className="w-12 h-12" />
          </div>
          <h1 className="text-5xl font-bold mb-4">HI-FI Livings</h1>
          <p className="text-xl opacity-80 max-w-md">Professional PG Rent Management System</p>
          <div className="mt-12 grid grid-cols-3 gap-8 text-center">
            <div><div className="text-3xl font-bold">150+</div><div className="text-sm opacity-70">Tenants</div></div>
            <div><div className="text-3xl font-bold">50+</div><div className="text-sm opacity-70">Rooms</div></div>
            <div><div className="text-3xl font-bold">24/7</div><div className="text-sm opacity-70">Support</div></div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8 bg-[var(--background)]">
        <div className="w-full max-w-md">
          {mode === 'select' && (
            <div className="fade-up">
              <div className="lg:hidden text-center mb-8">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#4f46e5] to-[#0284c7] flex items-center justify-center mx-auto mb-4">
                  <Building2 className="w-8 h-8 text-white" />
                </div>
                <h1 className="text-2xl font-bold">HI-FI Livings</h1>
                <p className="text-sm text-[var(--muted)]">Rent Management Portal</p>
              </div>
              <h2 className="text-2xl font-bold mb-2">Welcome Back</h2>
              <p className="text-[var(--muted)] mb-8">Select your role to continue</p>
              <div className="space-y-4">
                <button onClick={() => setMode('admin')} className="w-full card flex items-center gap-4 p-6 text-left group hover:border-[var(--primary)] transition-all">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#4f46e5] to-[#6366f1] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <User className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <div className="font-bold text-lg">Admin / Manager</div>
                    <div className="text-sm text-[var(--muted)]">Full dashboard access</div>
                  </div>
                  <ArrowRight className="w-5 h-5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
                <button onClick={() => setMode('tenant')} className="w-full card flex items-center gap-4 p-6 text-left group hover:border-[var(--primary)] transition-all">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#0284c7] to-[#38bdf8] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Users className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <div className="font-bold text-lg">Tenant / Resident</div>
                    <div className="text-sm text-[var(--muted)]">View your rent & payments</div>
                  </div>
                  <ArrowRight className="w-5 h-5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              </div>
            </div>
          )}

          {mode === 'admin' && <AdminLogin onBack={() => setMode('select')} onSignup={() => setMode('admin-signup')} showToast={showToast} onLoginSuccess={onLoginSuccess} />}
          {mode === 'admin-signup' && <AdminSignup onBack={() => setMode('admin')} showToast={showToast} onLoginSuccess={onLoginSuccess} />}
          {mode === 'tenant' && <TenantLogin onBack={() => setMode('select')} onRegister={() => setMode('register')} showToast={showToast} onLoginSuccess={onLoginSuccess} />}
          {mode === 'register' && <TenantRegister onBack={() => setMode('tenant')} showToast={showToast} />}
        </div>
      </div>

      {toast && <div className={`toast toast-${toast.type}`}>{toast.message}</div>}
    </div>
  )
}

function AdminLogin({ onBack, onSignup, showToast, onLoginSuccess }: { onBack: () => void; onSignup: () => void; showToast: (msg: string, type: 'success' | 'error') => void; onLoginSuccess: () => Promise<void> }) {
  const [state, formAction, isPending] = useActionState<ActionResult<{ name: string }>, FormData>(
    async (prev, formData) => adminLogin(formData), { success: false }
  )

  useEffect(() => {
    if (state.success) {
      showToast(`Welcome, ${state.data?.name}!`, 'success')
      onLoginSuccess()
    }
    else if (state.error) showToast(state.error, 'error')
  }, [state, showToast, onLoginSuccess])

  return (
    <div className="fade-up">
      <button onClick={onBack} className="text-sm text-[var(--muted)] hover:text-white mb-6 flex items-center gap-2">
        <ArrowRight className="w-4 h-4 rotate-180" /> Back
      </button>
      <h2 className="text-2xl font-bold mb-2">Admin Login</h2>
      <p className="text-[var(--muted)] mb-8">Enter your credentials</p>
      <form action={formAction} className="space-y-6">
        <div>
          <label className="block text-sm text-[var(--muted)] mb-2">Username</label>
          <div className="relative">
            <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--muted)]" />
            <input name="username" placeholder="admin" required disabled={isPending} className="pl-12" />
          </div>
        </div>
        <div>
          <label className="block text-sm text-[var(--muted)] mb-2">Password</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--muted)]" />
            <input type="password" name="password" placeholder="••••••••" required disabled={isPending} className="pl-12" />
          </div>
        </div>
        <button type="submit" disabled={isPending} className="btn btn-primary w-full">
          {isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> Signing in...</> : 'Sign In'}
        </button>
      </form>
      <div className="text-center mt-6">
        <p className="text-sm text-[var(--muted)]">
          First time?{' '}
          <button onClick={onSignup} className="text-[var(--primary)] hover:underline font-semibold">Create admin account</button>
        </p>
        <p className="text-xs text-[var(--muted)] mt-3">Default: admin / admin123</p>
      </div>
    </div>
  )
}

function AdminSignup({ onBack, showToast, onLoginSuccess }: { onBack: () => void; showToast: (msg: string, type: 'success' | 'error') => void; onLoginSuccess: () => Promise<void> }) {
  const [state, formAction, isPending] = useActionState<ActionResult<{ name: string }>, FormData>(
    async (prev, formData) => adminSignup(formData), { success: false }
  )

  useEffect(() => {
    if (state.success) {
      showToast('Account created! Logging in...', 'success')
      onLoginSuccess()
    }
    else if (state.error) showToast(state.error, 'error')
  }, [state, showToast, onLoginSuccess])

  return (
    <div className="fade-up">
      <button onClick={onBack} className="text-sm text-[var(--muted)] hover:text-white mb-6 flex items-center gap-2">
        <ArrowRight className="w-4 h-4 rotate-180" /> Back to login
      </button>
      <h2 className="text-2xl font-bold mb-2">Create Admin Account</h2>
      <p className="text-[var(--muted)] mb-8">Set up your PG management system</p>
      <form action={formAction} className="space-y-5">
        <div>
          <label className="block text-sm text-[var(--muted)] mb-2">Display Name</label>
          <input name="name" placeholder="e.g. HF Admin" required disabled={isPending} />
        </div>
        <div>
          <label className="block text-sm text-[var(--muted)] mb-2">Username</label>
          <input name="username" placeholder="e.g. admin" required disabled={isPending} />
        </div>
        <div>
          <label className="block text-sm text-[var(--muted)] mb-2">Password (6+ characters)</label>
          <input type="password" name="password" placeholder="••••••••" required minLength={6} disabled={isPending} />
        </div>
        <button type="submit" disabled={isPending} className="btn btn-primary w-full">
          {isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> Creating...</> : <><UserPlus className="w-5 h-5" /> Create Account</>}
        </button>
      </form>
    </div>
  )
}

function TenantLogin({ onBack, onRegister, showToast, onLoginSuccess }: { onBack: () => void; onRegister: () => void; showToast: (msg: string, type: 'success' | 'error') => void; onLoginSuccess: () => Promise<void> }) {
  const [state, formAction, isPending] = useActionState<ActionResult<{ name: string }>, FormData>(
    async (prev, formData) => tenantLogin(formData), { success: false }
  )

  useEffect(() => {
    if (state.success) {
      showToast(`Welcome, ${state.data?.name}!`, 'success')
      onLoginSuccess()
    }
    else if (state.error) showToast(state.error, 'error')
  }, [state, showToast, onLoginSuccess])

  return (
    <div className="fade-up">
      <button onClick={onBack} className="text-sm text-[var(--muted)] hover:text-white mb-6 flex items-center gap-2">
        <ArrowRight className="w-4 h-4 rotate-180" /> Back
      </button>
      <h2 className="text-2xl font-bold mb-2">Tenant Login</h2>
      <p className="text-[var(--muted)] mb-8">Enter your phone number</p>
      <form action={formAction} className="space-y-6">
        <div>
          <label className="block text-sm text-[var(--muted)] mb-2">Phone Number</label>
          <div className="relative">
            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--muted)]" />
            <input type="tel" name="phone" placeholder="9876543210" required disabled={isPending} className="pl-12" />
          </div>
        </div>
        <button type="submit" disabled={isPending} className="btn btn-primary w-full">
          {isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> Signing in...</> : 'Sign In'}
        </button>
      </form>
      <div className="text-center mt-6">
        <p className="text-sm text-[var(--muted)]">
          Not registered?{' '}
          <button onClick={onRegister} className="text-[var(--primary)] hover:underline font-semibold">Register now</button>
        </p>
      </div>
    </div>
  )
}

function TenantRegister({ onBack, showToast }: { onBack: () => void; showToast: (msg: string, type: 'success' | 'error') => void }) {
  const [state, formAction, isPending] = useActionState<ActionResult, FormData>(
    async (prev, formData) => submitRegistration(formData), { success: false }
  )

  useEffect(() => {
    if (state.success) { showToast('Registration submitted! Admin will approve.', 'success'); onBack() }
    else if (state.error) showToast(state.error, 'error')
  }, [state, showToast, onBack])

  return (
    <div className="fade-up">
      <button onClick={onBack} className="text-sm text-[var(--muted)] hover:text-white mb-6 flex items-center gap-2">
        <ArrowRight className="w-4 h-4 rotate-180" /> Back
      </button>
      <h2 className="text-2xl font-bold mb-2">Register as Tenant</h2>
      <p className="text-[var(--muted)] mb-8">Admin will approve your access</p>
      <form action={formAction} className="space-y-5">
        <div><label className="block text-sm text-[var(--muted)] mb-2">Full Name *</label><input name="name" placeholder="Your name" required disabled={isPending} /></div>
        <div><label className="block text-sm text-[var(--muted)] mb-2">Phone Number *</label><input type="tel" name="phone" placeholder="9876543210" required disabled={isPending} /></div>
        <div><label className="block text-sm text-[var(--muted)] mb-2">Preferred Room</label><input name="preferred_room" placeholder="e.g. 101" disabled={isPending} /></div>
        <div><label className="block text-sm text-[var(--muted)] mb-2">Cot Preference</label><input name="cot" placeholder="e.g. A" disabled={isPending} /></div>
        <div><label className="block text-sm text-[var(--muted)] mb-2">Note</label><input name="note" placeholder="Message for admin..." disabled={isPending} /></div>
        <button type="submit" disabled={isPending} className="btn btn-primary w-full">
          {isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> Submitting...</> : 'Submit Registration'}
        </button>
      </form>
    </div>
  )
}
