'use client'

import { useAuth } from '@/lib/auth-context'
import { LoginScreen } from './components/login-screen'
import { AdminDashboard } from './components/admin-dashboard'
import { TenantPortal } from './components/tenant-portal'
import { Loader2 } from 'lucide-react'

export default function Home() {
  const { role, loading, error, adminName, tenantId, tenantName } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--background)]">
        <Loader2 className="w-8 h-8 animate-spin text-[var(--primary)]" />
      </div>
    )
  }

  if (error || !role) {
    return <LoginScreen />
  }

  if (role === 'admin') {
    return <AdminDashboard userName={adminName || 'Admin'} />
  }

  if (role === 'tenant' && tenantId) {
    return <TenantPortal tenantId={tenantId} userName={tenantName || 'Tenant'} />
  }

  return <LoginScreen />
}
