'use client'

import { createContext, useContext, useEffect, useState, useCallback, useRef, type ReactNode } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { User } from '@supabase/supabase-js'

type AuthRole = 'admin' | 'tenant' | null

type AuthState = {
  user: User | null
  role: AuthRole
  adminName: string | null
  tenantId: string | null
  tenantName: string | null
  loading: boolean
  error: string | null
}

type AuthContextType = AuthState & {
  refresh: () => Promise<void>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    role: null,
    adminName: null,
    tenantId: null,
    tenantName: null,
    loading: true,
    error: null,
  })

  const supabaseRef = useRef(createClient())
  const supabase = supabaseRef.current
  const mountedRef = useRef(false)

  const determineRole = useCallback(async (user: User): Promise<Omit<AuthState, 'loading' | 'error'>> => {
    // Check admin role from database (not metadata)
    const { data: adminRow, error: adminErr } = await supabase
      .from('admins')
      .select('name')
      .eq('user_id', user.id)
      .single()

    // PGRST116 = no row found (not an admin), that's fine
    if (adminErr && adminErr.code !== 'PGRST116') {
      console.error('[AuthContext] Admin lookup error:', adminErr)
    }

    if (adminRow) {
      return { user, role: 'admin', adminName: adminRow.name, tenantId: null, tenantName: null }
    }

    // Not admin — check app_metadata for tenant routing info (set server-side only)
    const tenantId = user.app_metadata?.tenant_id as string | undefined
    const tenantName = user.app_metadata?.tenant_name as string | undefined

    if (tenantId) {
      return { user, role: 'tenant', adminName: null, tenantId, tenantName: tenantName || null }
    }

    // Authenticated but no role assignment found
    return { user, role: null, adminName: null, tenantId: null, tenantName: null }
  }, [supabase])

  const refresh = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true, error: null }))
    try {
      // First try getSession() — it reads from local storage/cookies without a server round-trip
      const { data: { session } } = await supabase.auth.getSession()

      if (!session?.user) {
        // No local session — try getUser() which makes a server call
        const { data: { user }, error: authError } = await supabase.auth.getUser()
        if (authError || !user) {
          setState({ user: null, role: null, adminName: null, tenantId: null, tenantName: null, loading: false, error: null })
          return
        }
        const roleData = await determineRole(user)
        setState({ ...roleData, loading: false, error: roleData.role ? null : 'No role assigned. Please sign in again.' })
        return
      }

      const roleData = await determineRole(session.user)
      setState({ ...roleData, loading: false, error: roleData.role ? null : 'No role assigned. Please sign in again.' })
    } catch (err) {
      console.error('[AuthContext] Refresh error:', err)
      setState(prev => ({ ...prev, loading: false, error: 'Authentication check failed.' }))
    }
  }, [supabase, determineRole])

  const handleSignOut = useCallback(async () => {
    await supabase.auth.signOut()
    setState({ user: null, role: null, adminName: null, tenantId: null, tenantName: null, loading: false, error: null })
  }, [supabase])

  useEffect(() => {
    mountedRef.current = true
    refresh()

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (!mountedRef.current) return
      if (event === 'SIGNED_OUT') {
        setState({ user: null, role: null, adminName: null, tenantId: null, tenantName: null, loading: false, error: null })
      } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        refresh()
      }
    })

    return () => {
      mountedRef.current = false
      subscription.unsubscribe()
    }
  }, [refresh, supabase])

  return (
    <AuthContext.Provider value={{ ...state, refresh, signOut: handleSignOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
