-- Add user_id to admins table for RLS
ALTER TABLE admins ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id);

-- Update existing main admin to link to their auth user
-- (will be set properly when admin logs in)

-- Drop insecure policies that reference user_metadata
DROP POLICY IF EXISTS select_admins ON admins;
DROP POLICY IF EXISTS insert_admins ON admins;
DROP POLICY IF EXISTS update_admins ON admins;
DROP POLICY IF EXISTS delete_admins ON admins;

-- Create secure policies using auth.uid() = user_id (same pattern as other tables)
CREATE POLICY "select_admins" ON admins FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_admins" ON admins FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_admins" ON admins FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_admins" ON admins FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Fix mutable search_path on update_updated_at function
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;