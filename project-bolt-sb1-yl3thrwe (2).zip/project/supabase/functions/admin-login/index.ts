import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { action, username, password, phone, name, preferred_room, cot, note, id, user_id } = await req.json();
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const authHeaders: Record<string, string> = {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
    };

    const fetchAdmin = (path: string, opts?: RequestInit) =>
      fetch(`${supabaseUrl}/rest/v1/${path}`, { ...opts, headers: { ...authHeaders, ...(opts?.headers || {}) } });

    if (action === "admin_login") {
      if (!username || !password) {
        return new Response(JSON.stringify({ error: "Missing fields" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const res = await fetchAdmin(`admins?username=eq.${encodeURIComponent(username)}&password=eq.${encodeURIComponent(password)}&select=id,username,name,password,user_id`);
      const admins = await res.json();
      if (!admins || admins.length === 0) {
        return new Response(JSON.stringify({ error: "Invalid credentials" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      // Don't return password to caller
      const { password: _p, ...safe } = admins[0];
      return new Response(JSON.stringify({ success: true, admin: safe }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "link_admin_user") {
      if (!username || !user_id) {
        return new Response(JSON.stringify({ error: "Missing fields" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const res = await fetchAdmin(`admins?username=eq.${encodeURIComponent(username)}`, {
        method: "PATCH",
        body: JSON.stringify({ user_id }),
      });
      if (!res.ok) {
        return new Response(JSON.stringify({ error: "Link failed" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "set_app_metadata") {
      if (!user_id) {
        return new Response(JSON.stringify({ error: "user_id required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      // Use Supabase Auth Admin API to set app_metadata (server-only, tamper-proof)
      const metaRes = await fetch(`${supabaseUrl}/auth/v1/admin/users/${user_id}`, {
        method: "PUT",
        headers: {
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          app_metadata: {
            tenant_id: tenant_id || null,
            tenant_name: tenant_name || null,
            phone: phone || null,
          },
        }),
      });
      if (!metaRes.ok) {
        const err = await metaRes.text();
        return new Response(JSON.stringify({ error: `Metadata update failed: ${err}` }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "tenant_lookup") {
      if (!phone) {
        return new Response(JSON.stringify({ error: "Phone required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const res = await fetchAdmin(`tenants?phone=eq.${encodeURIComponent(phone)}&is_approved=eq.true&is_active=eq.true&select=id,name,phone,user_id`);
      const tenants = await res.json();
      if (!tenants || tenants.length === 0) {
        return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const tenant = tenants[0];
      // Return admin username + password so server action can create auth session
      const adminRes = await fetchAdmin(`admins?select=username,password&limit=1`);
      const admins = await adminRes.json();
      const admin = admins?.[0] || null;
      return new Response(JSON.stringify({ success: true, tenant, admin }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "tenant_register") {
      if (!name || !phone) {
        return new Response(JSON.stringify({ error: "Name and phone required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const existRes = await fetchAdmin(`tenants?phone=eq.${encodeURIComponent(phone)}&select=id`);
      const existing = await existRes.json();
      if (existing && existing.length > 0) {
        return new Response(JSON.stringify({ error: "Phone already registered" }), { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const anyTenantRes = await fetchAdmin(`tenants?select=user_id&limit=1`);
      const anyTenant = await anyTenantRes.json();
      const userId = anyTenant?.[0]?.user_id;
      if (!userId) {
        return new Response(JSON.stringify({ error: "No admin setup yet" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const insertRes = await fetchAdmin("registrations", {
        method: "POST",
        body: JSON.stringify({ user_id: userId, name, phone, preferred_room: preferred_room || null, cot: cot || null, note: note || null }),
      });
      if (!insertRes.ok) {
        return new Response(JSON.stringify({ error: "Registration failed" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "get_admins") {
      const res = await fetchAdmin("admins?select=id,username,name,is_main,created_at,user_id&order=created_at.asc");
      const admins = await res.json();
      return new Response(JSON.stringify({ success: true, admins }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "add_admin") {
      if (!username || !password || !name) {
        return new Response(JSON.stringify({ error: "All fields required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const insertRes = await fetchAdmin("admins", {
        method: "POST",
        body: JSON.stringify({ username, password, name, is_main: false, user_id: user_id || null }),
      });
      if (!insertRes.ok) {
        const err = await insertRes.json();
        return new Response(JSON.stringify({ error: err.message || "Failed" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "delete_admin") {
      if (!id) {
        return new Response(JSON.stringify({ error: "ID required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const delRes = await fetchAdmin(`admins?id=eq.${encodeURIComponent(id)}&is_main=eq.false`, { method: "DELETE" });
      if (!delRes.ok) {
        return new Response(JSON.stringify({ error: "Failed" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
